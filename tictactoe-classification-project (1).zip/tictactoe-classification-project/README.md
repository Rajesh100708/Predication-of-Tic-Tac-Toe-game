# Predict the Next Move in Tic-Tac-Toe Using Classification

## Project overview
This project uses a **Decision Tree classification** model to predict a likely next Tic-Tac-Toe move from the current 3×3 board.

## Files
- `tic_tac_toe_classifier.py` — Python source code for preparing training examples, training/evaluating the classifier, and predicting a move.
- `tictactoe_games.csv` — dataset used by the program.
- `requirements.txt` — required Python libraries.
- `sample_output.txt` — example of the program interaction (illustrative; measured accuracy can vary with library versions).

## Dataset details
- File: `tictactoe_games.csv`
- Rows: 255,168 games
- Columns: 10 (`Winner` plus nine move columns)
- Move columns record each move as `row-col`, using zero-based row and column indices. `---` represents a move that did not occur.
- The script samples up to 30,000 games for faster training on a typical student computer.

## Requirements
- Python 3.10 or newer recommended
- pandas
- scikit-learn

## How to run
1. Install Python if it is not already installed.
2. Open Command Prompt or a terminal in this project folder.
3. Install dependencies:
   ```bash
   py -m pip install -r requirements.txt
   ```
4. Run the program:
   ```bash
   py tic_tac_toe_classifier.py
   ```
5. When prompted, enter nine cells separated by spaces. Use `X`, `O`, and `-` for empty cells. Example:
   ```text
   X O X O X - - O -
   ```

## Method
1. Read the CSV dataset.
2. Convert each recorded game into board-state examples and the next position played.
3. Encode `X` as `1`, `O` as `-1`, and an empty cell as `0`.
4. Split the examples into training and test sets.
5. Train a Decision Tree classifier and report accuracy.
6. Predict an unoccupied position for the user-entered board.

## Limitations
This is an educational classification demonstration. The prediction reflects patterns in the dataset and is **not guaranteed to be the optimal move**. The train/test split is performed over board states, so states from the same original game may appear in both sets; reported accuracy can therefore be optimistic. A stronger evaluation would split by original game and compare against a game-theoretic optimal strategy.

## Result
The project demonstrates how a classification algorithm can learn from recorded Tic-Tac-Toe games and predict a possible next move from a board configuration.
