"""Predict the next Tic-Tac-Toe move using a Decision Tree classifier."""

from pathlib import Path
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import accuracy_score, classification_report

DATASET_PATH = Path(__file__).with_name("tictactoe_games.csv")
BOARD_COLUMNS = ["P1", "P2", "P3", "P4", "P5", "P6", "P7", "P8", "P9"]
MOVE_COLUMNS = [
    "Move 1-X (Row-Col)", "Move 2-O (Row-Col)",
    "Move 3-X (Row-Col)", "Move 4-O (Row-Col)",
    "Move 5-X (Row-Col)", "Move 6-O (Row-Col)",
    "Move 7-X (Row-Col)", "Move 8-O (Row-Col)",
    "Move 9-X (Row-Col)",
]


def create_training_data(games: pd.DataFrame) -> tuple[pd.DataFrame, pd.Series]:
    """Turn recorded games into board-state / next-position examples."""
    states, targets = [], []

    for _, game in games.iterrows():
        board = [0] * 9
        for move_index, column in enumerate(MOVE_COLUMNS):
            move = game[column]
            if pd.isna(move) or str(move).strip() == "---":
                break

            try:
                row, col = map(int, str(move).split("-"))
            except (ValueError, AttributeError):
                break

            if row not in range(3) or col not in range(3):
                break
            position = row * 3 + col
            if board[position] != 0:
                break

            # Record the board before the move and the position played.
            states.append(board.copy())
            targets.append(position)
            board[position] = 1 if move_index % 2 == 0 else -1

    return pd.DataFrame(states, columns=BOARD_COLUMNS), pd.Series(targets, name="Next_Move")


def display_board(board: list[int]) -> None:
    symbols = {1: "X", -1: "O", 0: "-"}
    for start in (0, 3, 6):
        print(" | ".join(symbols[value] for value in board[start:start + 3]))
        if start < 6:
            print("---------")


def main() -> None:
    if not DATASET_PATH.exists():
        raise FileNotFoundError(
            f"Dataset not found: {DATASET_PATH}. Keep tictactoe_games.csv next to this script."
        )

    games = pd.read_csv(DATASET_PATH)
    missing = [column for column in MOVE_COLUMNS if column not in games.columns]
    if missing:
        raise ValueError(f"Dataset is missing expected columns: {missing}")

    # Sample games to keep training reasonably fast on a student computer.
    games = games.sample(n=min(30000, len(games)), random_state=42)
    X, y = create_training_data(games)
    if X.empty:
        raise ValueError("No training examples were created. Check the dataset format.")

    print("Dataset games used:", len(games))
    print("Board-state training examples:", len(X))

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42
    )
    model = DecisionTreeClassifier(max_depth=12, random_state=42)
    model.fit(X_train, y_train)

    predictions = model.predict(X_test)
    print(f"\nModel accuracy: {accuracy_score(y_test, predictions) * 100:.2f}%")
    print("\nClassification report:")
    print(classification_report(y_test, predictions, zero_division=0))

    print("\nEnter 9 cells separated by spaces (X, O, or - for empty).")
    print("Example: X O X O X - - O -")
    cells = input("Board: ").upper().split()
    if len(cells) != 9 or any(cell not in {"X", "O", "-"} for cell in cells):
        print("Invalid input. Enter exactly 9 values using X, O, and -.")
        return

    board = [1 if cell == "X" else -1 if cell == "O" else 0 for cell in cells]
    if 0 not in board:
        print("The board is full. No move is available.")
        return
    if board.count(1) not in (board.count(-1), board.count(-1) + 1):
        print("Invalid board: X and O counts are inconsistent.")
        return

    probabilities = model.predict_proba(pd.DataFrame([board], columns=BOARD_COLUMNS))[0]
    ranked_positions = sorted(zip(model.classes_, probabilities), key=lambda item: item[1], reverse=True)
    next_position = next((int(pos) for pos, _ in ranked_positions if board[int(pos)] == 0), None)
    if next_position is None:
        print("No empty position available.")
        return

    print("\nCurrent board:")
    display_board(board)
    print(f"\nPredicted move: row {next_position // 3}, column {next_position % 3}")
    print(f"Position (row-column): {next_position // 3}-{next_position % 3}")
    print("Note: This is a learned prediction, not a guarantee of the optimal move.")


if __name__ == "__main__":
    main()
